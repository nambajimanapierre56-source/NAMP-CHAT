
const form = document.getElementById("chatForm");
const input = document.getElementById("userInput");
const chat = document.getElementById("chat");

function addMessage(text, sender) {
  const message = document.createElement("div");
  message.className = "message " + sender;
  message.textContent = text;
  chat.appendChild(message);
  chat.scrollTop = chat.scrollHeight;
}

form.addEventListener("submit", function(event) {
  event.preventDefault();

  const question = input.value.trim();

  if (!question) return;

  addMessage(question, "user");
  input.value = "";

  const q = question.toLowerCase();
  let answer;

  if (q.includes("hello") || q.includes("hi")) {
    answer = "Hello! Welcome to My AI Assistant. How can I help you?";
  } else if (q.includes("your name")) {
    answer = "My name is My AI Assistant!";
  } else if (q.includes("math")) {
    answer = "I can help you learn mathematics. Ask me a specific math question!";
  } else if (q.includes("science")) {
    answer = "Science helps us understand the world. Which science topic interests you?";
  } else {
    answer = "Thank you for your question! I am currently a demo. We will connect a real AI model next.";
  }

  setTimeout(function() {
    addMessage(answer, "bot");
  }, 400);
});
